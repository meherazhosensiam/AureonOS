"""Main window: GNOME-Settings-style sidebar + content split view."""

from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, Gtk  # noqa: E402

from .logger import get_logger
from .models import CATEGORY_LABELS, Category
from .widgets.dashboard import DashboardPage
from .widgets.settings_page import SettingsPage
from .widgets.tool_list import ToolListPage

log = get_logger("window")

SIDEBAR_SECTIONS: list[tuple[str, list[tuple[str, str]]]] = [
    ("", [("dashboard", "Dashboard")]),
    (
        "Discover",
        [
            ("recommended", CATEGORY_LABELS[Category.RECOMMENDED]),
            ("reconnaissance", CATEGORY_LABELS[Category.RECONNAISSANCE]),
            ("information_gathering", CATEGORY_LABELS[Category.INFO_GATHERING]),
            ("osint", CATEGORY_LABELS[Category.OSINT]),
            ("web_security", CATEGORY_LABELS[Category.WEB_SECURITY]),
            ("network_security", CATEGORY_LABELS[Category.NETWORK_SECURITY]),
            ("wireless_security", CATEGORY_LABELS[Category.WIRELESS_SECURITY]),
            ("password_auditing", CATEGORY_LABELS[Category.PASSWORD_AUDITING]),
            ("active_directory", CATEGORY_LABELS[Category.ACTIVE_DIRECTORY]),
            ("exploitation", CATEGORY_LABELS[Category.EXPLOITATION]),
            ("post_exploitation", CATEGORY_LABELS[Category.POST_EXPLOITATION]),
            ("malware_analysis", CATEGORY_LABELS[Category.MALWARE_ANALYSIS]),
            ("reverse_engineering", CATEGORY_LABELS[Category.REVERSE_ENGINEERING]),
            ("digital_forensics", CATEGORY_LABELS[Category.DIGITAL_FORENSICS]),
            ("mobile_security", CATEGORY_LABELS[Category.MOBILE_SECURITY]),
            ("cloud_security", CATEGORY_LABELS[Category.CLOUD_SECURITY]),
            ("container_security", CATEGORY_LABELS[Category.CONTAINER_SECURITY]),
            ("ics_iot", CATEGORY_LABELS[Category.ICS_IOT]),
            ("cryptography", CATEGORY_LABELS[Category.CRYPTOGRAPHY]),
            ("fuzzing", CATEGORY_LABELS[Category.FUZZING]),
            ("privacy", CATEGORY_LABELS[Category.PRIVACY]),
            ("anonymous_browsing", CATEGORY_LABELS[Category.ANONYMOUS_BROWSING]),
            ("utilities", CATEGORY_LABELS[Category.UTILITIES]),
        ],
    ),
    (
        "Manage",
        [
            ("installed", "Installed Tools"),
            ("updates", "Updates"),
        ],
    ),
    ("", [("settings", "Settings"), ("about", "About")]),
]


class AureonWindow(Adw.ApplicationWindow):
    """The single top-level window of the application."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.set_title("AUREON Security Center")
        self.set_default_size(1180, 760)

        app = self.get_application()
        self.database = app.database
        self.detector = app.detector
        self.installer = app.installer

        self._pages: dict[str, Gtk.Widget] = {}

        self.split_view = Adw.NavigationSplitView()
        self.set_content(self.split_view)

        self.split_view.set_sidebar(self._build_sidebar())
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE)
        content_page = Adw.NavigationPage(title="AUREON Security Center", child=self._build_content())
        self.split_view.set_content(content_page)

        self._build_pages()
        self.show_page("dashboard")

    # -- sidebar -----------------------------------------------------
    def _build_sidebar(self) -> Adw.NavigationPage:
        toolbar_view = Adw.ToolbarView()
        header = Adw.HeaderBar()
        header.set_title_widget(Adw.WindowTitle(title="AUREON", subtitle="Security Center"))
        toolbar_view.add_top_bar(header)

        search_entry = Gtk.SearchEntry(placeholder_text="Search tools\u2026")
        search_entry.connect("search-changed", self._on_search_changed)
        search_bar_box = Gtk.Box(margin_start=8, margin_end=8, margin_top=8, margin_bottom=4)
        search_bar_box.append(search_entry)
        toolbar_view.add_top_bar(search_bar_box)

        listbox = Gtk.ListBox(css_classes=["navigation-sidebar"])
        listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)

        for section_title, rows in SIDEBAR_SECTIONS:
            if section_title:
                header_row = Gtk.Label(
                    label=section_title,
                    css_classes=["dim-label", "caption-heading"],
                    xalign=0,
                    margin_start=12,
                    margin_top=10,
                    margin_bottom=2,
                )
                listbox.append(header_row)
                listbox.get_row_at_index(listbox.observe_children().get_n_items() - 1)
            for page_id, label in rows:
                row = Adw.ActionRow(title=label)
                row.set_activatable(True)
                row.page_id = page_id  # type: ignore[attr-defined]
                listbox.append(row)

        listbox.connect("row-activated", self._on_sidebar_row_activated)
        scroller = Gtk.ScrolledWindow(child=listbox, vexpand=True)
        toolbar_view.set_content(scroller)

        return Adw.NavigationPage(title="Categories", child=toolbar_view)

    def _on_sidebar_row_activated(self, _listbox: Gtk.ListBox, row: Gtk.ListBoxRow) -> None:
        page_id = getattr(row, "page_id", None)
        if page_id:
            self.show_page(page_id)

    def _on_search_changed(self, entry: Gtk.SearchEntry) -> None:
        query = entry.get_text()
        self.show_page("search")
        page = self._pages.get("search")
        if isinstance(page, ToolListPage):
            page.set_tools(self.database.search(query), title=f'Search: "{query}"' if query else "Search")

    # -- content -----------------------------------------------------
    def _build_content(self) -> Gtk.Widget:
        return self.stack

    def _build_pages(self) -> None:
        self._pages["dashboard"] = DashboardPage(self)
        self.stack.add_named(self._pages["dashboard"], "dashboard")

        for _section, rows in SIDEBAR_SECTIONS:
            for page_id, label in rows:
                if page_id in {"dashboard", "settings", "about"}:
                    continue
                if page_id == "installed":
                    page = ToolListPage(self, tools=[], title="Installed Tools", filter_installed=True)
                elif page_id == "updates":
                    page = ToolListPage(self, tools=[], title="Updates", filter_updates=True)
                else:
                    page = ToolListPage(
                        self,
                        tools=self.database.by_category(page_id),
                        title=label,
                    )
                self._pages[page_id] = page
                self.stack.add_named(page, page_id)

        search_page = ToolListPage(self, tools=[], title="Search")
        self._pages["search"] = search_page
        self.stack.add_named(search_page, "search")

        settings_page = SettingsPage(self)
        self._pages["settings"] = settings_page
        self.stack.add_named(settings_page, "settings")

    def show_page(self, page_id: str) -> None:
        if page_id == "about":
            self.get_application().activate_action("about", None)
            return
        page = self._pages.get(page_id)
        if page is None:
            log.warning("Unknown page requested: %s", page_id)
            return
        if hasattr(page, "refresh"):
            page.refresh()
        self.stack.set_visible_child_name(page_id)
