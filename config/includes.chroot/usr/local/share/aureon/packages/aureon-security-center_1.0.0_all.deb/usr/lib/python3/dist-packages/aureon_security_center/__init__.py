"""AUREON Security Center.

A beginner-friendly, GTK4/Libadwaita graphical application for browsing,
installing, updating, removing and launching publicly available cybersecurity
and ethical hacking tools on AUREON OS (Debian-based) through standard,
trusted package managers (apt, pipx, pip, flatpak, cargo, go, npm, git,
AppImage).

This package intentionally never executes arbitrary/unvalidated shell
strings. All installation actions are built from a fixed, whitelisted set of
command templates defined in :mod:`aureon_security_center.installer`, and any
action that touches the system (installing packages, writing files outside
the user's home) is escalated through PolicyKit (``pkexec``) rather than by
running the whole application as root.
"""

__version__ = "1.0.0"
__app_id__ = "com.aureon.SecurityCenter"
