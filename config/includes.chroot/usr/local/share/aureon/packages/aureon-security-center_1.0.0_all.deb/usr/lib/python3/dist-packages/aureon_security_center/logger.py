"""Centralised logging configuration.

All operations performed by the installation engine are logged so that
users (and support requests / bug reports) have a full, auditable trail of
what the application did to the system.
"""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

APP_LOG_DIR = Path.home() / ".local" / "share" / "aureon-security-center" / "logs"
APP_LOG_FILE = APP_LOG_DIR / "aureon.log"

_configured = False


def setup_logging(verbose: bool = False) -> logging.Logger:
    """Configure and return the application's root logger.

    Safe to call multiple times; configuration is only applied once.
    """
    global _configured
    logger = logging.getLogger("aureon")

    if _configured:
        return logger

    APP_LOG_DIR.mkdir(parents=True, exist_ok=True)

    logger.setLevel(logging.DEBUG)

    file_handler = logging.handlers.RotatingFileHandler(
        APP_LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    )
    file_handler.setFormatter(file_formatter)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    console_formatter = logging.Formatter("%(levelname)-8s %(message)s")
    console_handler.setFormatter(console_formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    _configured = True
    logger.debug("Logging initialised. Log file: %s", APP_LOG_FILE)
    return logger


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"aureon.{name}")
