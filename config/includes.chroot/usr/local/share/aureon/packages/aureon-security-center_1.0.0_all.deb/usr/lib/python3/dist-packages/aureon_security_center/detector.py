"""Detects whether catalogued tools are already installed on the system.

Detection is read-only: it only ever queries the system (``which``, ``dpkg
-s``, ``pip show``, ...); it never mutates anything.
"""

from __future__ import annotations

import shutil
import subprocess

from .logger import get_logger
from .models import InstallMethod, Tool

log = get_logger("detector")


class InstallationDetector:
    """Read-only checks for whether a :class:`Tool` is already installed."""

    def is_installed(self, tool: Tool) -> bool:
        try:
            method = InstallMethod(tool.install_method)
        except ValueError:
            log.warning("Unknown install method %r for %s", tool.install_method, tool.id)
            return False

        checker = {
            InstallMethod.APT: self._check_apt,
            InstallMethod.FLATPAK: self._check_flatpak,
            InstallMethod.SNAP: self._check_snap,
            InstallMethod.PIPX: self._check_pipx,
            InstallMethod.PIP: self._check_pip,
            InstallMethod.CARGO: self._check_binary,
            InstallMethod.GO: self._check_binary,
            InstallMethod.NPM: self._check_npm,
            InstallMethod.GIT: self._check_git_clone,
            InstallMethod.APPIMAGE: self._check_binary,
            InstallMethod.TARBALL: self._check_binary,
        }.get(method, self._check_binary)

        try:
            return checker(tool)
        except Exception:  # defensive: detection must never crash the UI
            log.exception("Detection failed for %s", tool.id)
            return False

    # -- individual checkers ------------------------------------------
    def _run_ok(self, cmd: list[str]) -> bool:
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=10, check=False
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def _check_apt(self, tool: Tool) -> bool:
        return self._run_ok(["dpkg", "-s", tool.package_name])

    def _check_flatpak(self, tool: Tool) -> bool:
        if not shutil.which("flatpak"):
            return False
        return self._run_ok(["flatpak", "info", tool.package_name])

    def _check_snap(self, tool: Tool) -> bool:
        if not shutil.which("snap"):
            return False
        return self._run_ok(["snap", "list", tool.package_name])

    def _check_pipx(self, tool: Tool) -> bool:
        if not shutil.which("pipx"):
            return False
        result = subprocess.run(
            ["pipx", "list", "--short"], capture_output=True, text=True, timeout=10
        )
        return tool.package_name in result.stdout

    def _check_pip(self, tool: Tool) -> bool:
        return self._run_ok(["python3", "-m", "pip", "show", tool.package_name])

    def _check_npm(self, tool: Tool) -> bool:
        if not shutil.which("npm"):
            return False
        return self._run_ok(["npm", "list", "-g", tool.package_name])

    def _check_git_clone(self, tool: Tool) -> bool:
        return self._check_binary(tool)

    def _check_binary(self, tool: Tool) -> bool:
        binary = tool.launch_command.split()[0] if tool.launch_command else tool.package_name
        return shutil.which(binary) is not None
