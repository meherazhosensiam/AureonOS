"""A single tool card, plus the detail/beginner-explanation dialog."""

from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, GLib, Gtk  # noqa: E402

from ..installer import ActionKind, InstallError, StepEvent
from ..logger import get_logger
from ..models import Tool

log = get_logger("tool_card")

DIFFICULTY_COLORS = {
    "beginner": "success",
    "intermediate": "warning",
    "advanced": "error",
}


class ToolCard(Gtk.Box):
    """Compact card shown in grid/list views. Click opens the detail dialog."""

    def __init__(self, window, tool: Tool) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8, css_classes=["card"])
        self.window = window
        self.tool = tool
        self.set_margin_top(4)
        self.set_margin_bottom(4)

        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_top=14,
                         margin_bottom=14, margin_start=14, margin_end=14)

        header_box = Gtk.Box(spacing=10)
        icon = Gtk.Image.new_from_icon_name(tool.icon)
        icon.set_pixel_size(32)
        header_box.append(icon)

        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, hexpand=True)
        title_box.append(Gtk.Label(label=tool.name, css_classes=["heading"], xalign=0))
        badge = Gtk.Label(
            label=tool.difficulty.title(),
            css_classes=["caption", DIFFICULTY_COLORS.get(tool.difficulty, "accent")],
            xalign=0,
        )
        title_box.append(badge)
        header_box.append(title_box)

        self.status_icon = Gtk.Image()
        header_box.append(self.status_icon)
        inner.append(header_box)

        desc = Gtk.Label(label=tool.description, xalign=0, wrap=True, lines=2,
                          ellipsize=3, css_classes=["dim-label"])
        inner.append(desc)

        button_box = Gtk.Box(spacing=6, margin_top=6)
        self.primary_button = Gtk.Button(label="Install", css_classes=["suggested-action"])
        self.primary_button.connect("clicked", self._on_primary_clicked)
        details_button = Gtk.Button(label="Details")
        details_button.connect("clicked", lambda *_: self._open_detail())
        button_box.append(self.primary_button)
        button_box.append(details_button)
        inner.append(button_box)

        self.append(inner)
        self._refresh_state()

    def _refresh_state(self) -> None:
        installed = self.window.detector.is_installed(self.tool)
        if installed:
            self.status_icon.set_from_icon_name("emblem-ok-symbolic")
            self.primary_button.set_label("Launch" if self.tool.launch_command else "Installed")
            self.primary_button.set_sensitive(bool(self.tool.launch_command))
        else:
            self.status_icon.set_from_icon_name("")
            self.primary_button.set_label("Install")
            self.primary_button.set_sensitive(True)

    def _on_primary_clicked(self, *_args) -> None:
        installed = self.window.detector.is_installed(self.tool)
        if installed and self.tool.launch_command:
            try:
                self.window.installer.launch(self.tool)
            except InstallError as exc:
                self._toast(str(exc))
            return
        self._open_detail(auto_confirm=False)

    def _open_detail(self, auto_confirm: bool = False) -> None:
        dialog = ToolDetailDialog(self.window, self.tool, on_changed=self._refresh_state)
        dialog.present(self.window)

    def _toast(self, message: str) -> None:
        toast_overlay = getattr(self.window, "toast_overlay", None)
        if toast_overlay:
            toast_overlay.add_toast(Adw.Toast(title=message))
        else:
            log.warning(message)


class ToolDetailDialog(Adw.Dialog):
    """Full detail view: beginner explanation, metadata, and action buttons."""

    def __init__(self, window, tool: Tool, on_changed=None) -> None:
        super().__init__(title=tool.name, content_width=560, content_height=640)
        self.window = window
        self.tool = tool
        self.on_changed = on_changed

        toolbar_view = Adw.ToolbarView()
        header = Adw.HeaderBar()
        toolbar_view.add_top_bar(header)

        scroller = Gtk.ScrolledWindow(vexpand=True)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14,
                       margin_top=18, margin_bottom=18, margin_start=18, margin_end=18)

        box.append(Gtk.Label(label=tool.description, xalign=0, wrap=True))

        if tool.when_to_use:
            box.append(self._section("When to use it", tool.when_to_use))
        if tool.risks:
            box.append(self._section("Risks & legal notes", tool.risks))
        if tool.recommended_tutorials:
            box.append(self._section("Recommended tutorials", "\n".join(f"\u2022 {t}" for t in tool.recommended_tutorials)))

        meta_group = Adw.PreferencesGroup(title="Details")
        meta_group.add(self._meta_row("Category", tool.category_label))
        meta_group.add(self._meta_row("Difficulty", tool.difficulty.title()))
        meta_group.add(self._meta_row("Version", tool.version))
        meta_group.add(self._meta_row("Install method", tool.install_method))
        meta_group.add(self._meta_row("Package", tool.package_name))
        meta_group.add(self._meta_row("License", tool.license))
        if tool.dependencies:
            meta_group.add(self._meta_row("Dependencies", ", ".join(tool.dependencies)))
        if tool.size_estimate_mb:
            meta_group.add(self._meta_row("Estimated size", f"{tool.size_estimate_mb} MB"))
        box.append(meta_group)

        links_box = Gtk.Box(spacing=6)
        if tool.homepage:
            links_box.append(self._link_button("Website", tool.homepage))
        if tool.documentation_url:
            links_box.append(self._link_button("Documentation", tool.documentation_url))
        if tool.github_url:
            links_box.append(self._link_button("Source", tool.github_url))
        box.append(links_box)

        self.progress_bar = Gtk.ProgressBar(visible=False)
        box.append(self.progress_bar)

        self.log_view = Gtk.TextView(editable=False, monospace=True, visible=False)
        log_scroller = Gtk.ScrolledWindow(child=self.log_view, min_content_height=140, visible=False)
        self.log_scroller = log_scroller
        box.append(log_scroller)

        action_box = Gtk.Box(spacing=8, margin_top=6)
        installed = window.detector.is_installed(tool)
        if installed:
            if tool.launch_command:
                launch_btn = Gtk.Button(label="Launch", css_classes=["suggested-action"])
                launch_btn.connect("clicked", self._on_launch)
                action_box.append(launch_btn)
            update_btn = Gtk.Button(label="Update")
            update_btn.connect("clicked", self._on_update)
            action_box.append(update_btn)
            remove_btn = Gtk.Button(label="Remove", css_classes=["destructive-action"])
            remove_btn.connect("clicked", self._on_remove)
            action_box.append(remove_btn)
        else:
            install_btn = Gtk.Button(label="Install", css_classes=["suggested-action"])
            install_btn.connect("clicked", self._on_install)
            action_box.append(install_btn)
        box.append(action_box)

        scroller.set_child(box)
        toolbar_view.set_content(scroller)
        self.set_child(toolbar_view)

    def _section(self, title: str, body: str) -> Gtk.Widget:
        wrapper = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        wrapper.append(Gtk.Label(label=title, css_classes=["heading"], xalign=0))
        wrapper.append(Gtk.Label(label=body, xalign=0, wrap=True, css_classes=["dim-label"]))
        return wrapper

    def _meta_row(self, title: str, value: str) -> Adw.ActionRow:
        row = Adw.ActionRow(title=title)
        row.add_suffix(Gtk.Label(label=value, css_classes=["dim-label"]))
        return row

    def _link_button(self, label: str, uri: str) -> Gtk.Widget:
        btn = Gtk.LinkButton(uri=uri, label=label)
        return btn

    # -- actions -----------------------------------------------------
    def _on_install(self, *_a) -> None:
        self._run_action(ActionKind.INSTALL)

    def _on_update(self, *_a) -> None:
        self._run_action(ActionKind.UPDATE)

    def _on_remove(self, *_a) -> None:
        self._run_action(ActionKind.REMOVE)

    def _on_launch(self, *_a) -> None:
        try:
            self.window.installer.launch(self.tool)
        except InstallError as exc:
            log.error(str(exc))

    def _run_action(self, action: ActionKind) -> None:
        self.progress_bar.set_visible(True)
        self.progress_bar.pulse()
        self.log_scroller.set_visible(True)
        self.log_view.set_visible(True)

        import threading

        def worker() -> None:
            def on_event(event: StepEvent) -> None:
                GLib.idle_add(self._append_log, event.message if not event.line else event.line)

            try:
                engine = self.window.installer
                if action is ActionKind.INSTALL:
                    engine.install(self.tool, on_event=on_event)
                elif action is ActionKind.UPDATE:
                    engine.update(self.tool, on_event=on_event)
                else:
                    engine.remove(self.tool, on_event=on_event)
                GLib.idle_add(self._on_finished, True, None)
            except InstallError as exc:
                GLib.idle_add(self._on_finished, False, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _append_log(self, line: str) -> bool:
        buf = self.log_view.get_buffer()
        buf.insert(buf.get_end_iter(), line + "\n")
        return False

    def _on_finished(self, success: bool, error: str | None) -> bool:
        self.progress_bar.set_visible(False)
        if not success and error:
            self._append_log(f"ERROR: {error}")
        if self.on_changed:
            self.on_changed()
        return False
