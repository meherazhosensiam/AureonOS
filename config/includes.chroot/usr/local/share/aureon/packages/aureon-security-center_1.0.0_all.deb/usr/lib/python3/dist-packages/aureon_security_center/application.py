"""The Adw.Application subclass that bootstraps AUREON Security Center."""

from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, Gio, GLib, Gtk  # noqa: E402

from . import __app_id__, __version__
from .database import ToolDatabase
from .detector import InstallationDetector
from .installer import InstallationEngine
from .logger import get_logger, setup_logging
from .window import AureonWindow

log = get_logger("application")


class AureonApplication(Adw.Application):
    """Top-level application object.

    Owns the long-lived services (tool database, installer, detector) and
    hands them to the main window. Kept deliberately thin: all UI logic
    lives in :mod:`aureon_security_center.window` and the widgets package.
    """

    def __init__(self) -> None:
        super().__init__(
            application_id=__app_id__,
            flags=Gio.ApplicationFlags.DEFAULT_FLAGS,
        )
        setup_logging()
        self.database = ToolDatabase()
        self.detector = InstallationDetector()
        self.installer = InstallationEngine()

        self.add_main_option(
            "verbose",
            ord("v"),
            GLib.OptionFlags.NONE,
            GLib.OptionArg.NONE,
            "Enable verbose logging",
            None,
        )

    def do_activate(self) -> None:  # noqa: D401 (GObject virtual method)
        window = self.props.active_window
        if not window:
            window = AureonWindow(application=self)
        window.present()

    def do_startup(self) -> None:
        Adw.Application.do_startup(self)
        self._setup_actions()

    def _setup_actions(self) -> None:
        about_action = Gio.SimpleAction.new("about", None)
        about_action.connect("activate", self._on_about)
        self.add_action(about_action)

        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", lambda *_: self.quit())
        self.add_action(quit_action)
        self.set_accels_for_action("app.quit", ["<primary>q"])

    def _on_about(self, *_args) -> None:
        about = Adw.AboutWindow(
            transient_for=self.props.active_window,
            application_name="AUREON Security Center",
            application_icon="security-high-symbolic",
            version=__version__,
            developer_name="AUREON OS Project",
            license_type=Gtk.License.MIT_X11,
            comments=(
                "Browse, install, update, remove and launch cybersecurity "
                "and ethical hacking tools on AUREON OS."
            ),
            website="https://example.org/aureon-os",
            issue_url="https://example.org/aureon-os/issues",
        )
        about.present()
