"""Generic grid page listing tools for a category, search results, etc."""

from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, Gtk  # noqa: E402

from ..models import Tool
from .tool_card import ToolCard


class ToolListPage(Gtk.Box):
    def __init__(
        self,
        window,
        tools: list[Tool],
        title: str,
        filter_installed: bool = False,
        filter_updates: bool = False,
    ) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.window = window
        self._base_tools = tools
        self.filter_installed = filter_installed
        self.filter_updates = filter_updates

        header = Adw.HeaderBar(show_title=False)
        self.append(header)

        scroller = Gtk.ScrolledWindow(vexpand=True)
        clamp = Adw.Clamp(maximum_size=1100)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12,
                           margin_top=20, margin_bottom=20, margin_start=18, margin_end=18)

        self.title_label = Gtk.Label(label=title, css_classes=["title-1"], xalign=0)
        content.append(self.title_label)

        self.count_label = Gtk.Label(label="", xalign=0, css_classes=["dim-label"])
        content.append(self.count_label)

        self.flow_box = Gtk.FlowBox(
            selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=3,
            homogeneous=True, row_spacing=14, column_spacing=14, margin_top=8,
        )
        content.append(self.flow_box)

        self.empty_status = Adw.StatusPage(
            title="No tools found", icon_name="system-search-symbolic", visible=False,
        )
        content.append(self.empty_status)

        clamp.set_child(content)
        scroller.set_child(clamp)
        self.append(scroller)

        self.set_tools(tools, title=title)

    def set_tools(self, tools: list[Tool], title: str | None = None) -> None:
        self._base_tools = tools
        if title is not None:
            self.title_label.set_label(title)
        self._rebuild()

    def refresh(self) -> None:
        self._rebuild()

    def _rebuild(self) -> None:
        detector = self.window.detector
        tools = self._base_tools

        if self.filter_installed:
            tools = [t for t in self.window.database.all() if detector.is_installed(t)]
        elif self.filter_updates:
            # In a full implementation this would compare installed vs
            # upstream versions; placeholder keeps the page functional.
            tools = []

        child = self.flow_box.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.flow_box.remove(child)
            child = nxt

        self.count_label.set_label(f"{len(tools)} tool{'s' if len(tools) != 1 else ''}")
        self.empty_status.set_visible(len(tools) == 0)

        for tool in tools:
            card = ToolCard(self.window, tool)
            card.set_size_request(320, -1)
            self.flow_box.append(card)
