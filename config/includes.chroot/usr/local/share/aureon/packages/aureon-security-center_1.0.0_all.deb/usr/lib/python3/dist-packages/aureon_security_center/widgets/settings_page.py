"""Settings page: mirrors, parallel downloads, theme, install defaults."""

from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, Gio, Gtk  # noqa: E402

from ..logger import get_logger

log = get_logger("settings")

SCHEMA_ID = "com.aureon.SecurityCenter"


class SettingsPage(Gtk.Box):
    """User-configurable preferences, backed by GSettings when available.

    Falls back to in-memory defaults (with a log warning) when the compiled
    GSettings schema isn't installed yet, e.g. when running from a source
    checkout before `meson install` / packaging.
    """

    def __init__(self, window) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.window = window
        self._settings = self._load_settings()

        header = Adw.HeaderBar(show_title=False)
        self.append(header)

        scroller = Gtk.ScrolledWindow(vexpand=True)
        clamp = Adw.Clamp(maximum_size=760)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18,
                           margin_top=20, margin_bottom=20, margin_start=18, margin_end=18)
        content.append(Gtk.Label(label="Settings", css_classes=["title-1"], xalign=0))

        general_group = Adw.PreferencesGroup(title="General")
        general_group.add(self._switch_row("Dark mode", "dark-mode"))
        general_group.add(self._switch_row("Create desktop launchers automatically", "auto-desktop-launcher"))
        general_group.add(self._switch_row("Automatic updates", "auto-updates"))
        content.append(general_group)

        downloads_group = Adw.PreferencesGroup(title="Downloads")
        downloads_group.add(self._spin_row("Parallel downloads", "parallel-downloads", 1, 10))
        downloads_group.add(self._entry_row("Download mirror", "download-mirror"))
        content.append(downloads_group)

        install_group = Adw.PreferencesGroup(title="Installation")
        install_group.add(
            self._combo_row(
                "Default installation method",
                "default-install-method",
                ["apt", "flatpak", "pipx", "pip", "cargo", "go", "npm", "git"],
            )
        )
        content.append(install_group)

        maintenance_group = Adw.PreferencesGroup(title="Maintenance")
        clean_btn = Gtk.Button(label="Clean package caches now")
        clean_btn.connect("clicked", self._on_clean_cache)
        clean_row = Adw.ActionRow(title="Cache cleanup", subtitle="Frees disk space used by package manager caches")
        clean_row.add_suffix(clean_btn)
        maintenance_group.add(clean_row)

        refresh_btn = Gtk.Button(label="Refresh package lists")
        refresh_btn.connect("clicked", self._on_refresh_lists)
        refresh_row = Adw.ActionRow(title="Package lists", subtitle="Refresh apt package lists")
        refresh_row.add_suffix(refresh_btn)
        maintenance_group.add(refresh_row)

        content.append(maintenance_group)
        clamp.set_child(content)
        scroller.set_child(clamp)
        self.append(scroller)

    def _load_settings(self):
        try:
            source = Gio.SettingsSchemaSource.get_default()
            if source and source.lookup(SCHEMA_ID, True):
                return Gio.Settings.new(SCHEMA_ID)
        except Exception:  # pragma: no cover - defensive
            pass
        log.warning("GSettings schema %s not installed; using in-memory defaults", SCHEMA_ID)
        return None

    def _switch_row(self, title: str, key: str) -> Adw.ActionRow:
        row = Adw.ActionRow(title=title)
        switch = Gtk.Switch(valign=Gtk.Align.CENTER)
        if self._settings:
            self._settings.bind(key, switch, "active", Gio.SettingsBindFlags.DEFAULT)
        row.add_suffix(switch)
        row.set_activatable_widget(switch)
        return row

    def _spin_row(self, title: str, key: str, lower: int, upper: int) -> Adw.ActionRow:
        row = Adw.ActionRow(title=title)
        adjustment = Gtk.Adjustment(value=3, lower=lower, upper=upper, step_increment=1)
        spin = Gtk.SpinButton(adjustment=adjustment, valign=Gtk.Align.CENTER)
        if self._settings:
            self._settings.bind(key, adjustment, "value", Gio.SettingsBindFlags.DEFAULT)
        row.add_suffix(spin)
        return row

    def _entry_row(self, title: str, key: str) -> Adw.EntryRow:
        row = Adw.EntryRow(title=title)
        if self._settings:
            self._settings.bind(key, row, "text", Gio.SettingsBindFlags.DEFAULT)
        return row

    def _combo_row(self, title: str, key: str, options: list[str]) -> Adw.ComboRow:
        model = Gtk.StringList.new(options)
        row = Adw.ComboRow(title=title, model=model)
        if self._settings:
            self._settings.bind(key, row, "selected", Gio.SettingsBindFlags.DEFAULT)
        return row

    def _on_clean_cache(self, *_a) -> None:
        self.window.installer.clean_cache()

    def _on_refresh_lists(self, *_a) -> None:
        self.window.installer.refresh_package_lists()
