"""Dashboard: at-a-glance overview of the catalogue and system state."""

from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")

from gi.repository import Adw, Gtk  # noqa: E402


class StatCard(Gtk.Box):
    def __init__(self, title: str, value: str, icon_name: str = "emblem-ok-symbolic") -> None:
        super().__init__(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=6,
            css_classes=["card"],
            margin_top=12,
            margin_bottom=12,
            margin_start=12,
            margin_end=12,
        )
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_top=16,
                         margin_bottom=16, margin_start=16, margin_end=16)
        icon = Gtk.Image.new_from_icon_name(icon_name)
        icon.set_pixel_size(28)
        self.value_label = Gtk.Label(label=value, css_classes=["title-1"], xalign=0)
        title_label = Gtk.Label(label=title, css_classes=["dim-label"], xalign=0)
        inner.append(icon)
        inner.append(self.value_label)
        inner.append(title_label)
        self.append(inner)

    def set_value(self, value: str) -> None:
        self.value_label.set_label(value)


class DashboardPage(Gtk.Box):
    """Landing page shown when the app opens."""

    def __init__(self, window) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.window = window

        header = Adw.HeaderBar(show_title=False)
        self.append(header)

        scroller = Gtk.ScrolledWindow(vexpand=True)
        clamp = Adw.Clamp(maximum_size=1000)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18,
                           margin_top=24, margin_bottom=24, margin_start=18, margin_end=18)

        title = Gtk.Label(label="Dashboard", css_classes=["title-1"], xalign=0)
        content.append(title)

        self.stats_grid = Gtk.Grid(column_spacing=12, row_spacing=12, column_homogeneous=True)
        content.append(self.stats_grid)

        self.total_card = StatCard("Available Tools", "0", "system-search-symbolic")
        self.installed_card = StatCard("Installed", "0", "emblem-ok-symbolic")
        self.updates_card = StatCard("Updates Available", "0", "software-update-available-symbolic")
        self.storage_card = StatCard("Storage Used", "0 MB", "drive-harddisk-symbolic")
        self.queue_card = StatCard("Install Queue", "0", "view-list-symbolic")

        for i, card in enumerate(
            [self.total_card, self.installed_card, self.updates_card, self.storage_card, self.queue_card]
        ):
            self.stats_grid.attach(card, i % 5, 0, 1, 1)

        recommended_title = Gtk.Label(label="Recommended for Beginners", css_classes=["title-3"], xalign=0,
                                       margin_top=12)
        content.append(recommended_title)

        self.recommended_box = Gtk.FlowBox(
            selection_mode=Gtk.SelectionMode.NONE, max_children_per_line=3, homogeneous=True,
            row_spacing=12, column_spacing=12,
        )
        content.append(self.recommended_box)

        activity_title = Gtk.Label(label="Recent Activity", css_classes=["title-3"], xalign=0, margin_top=12)
        content.append(activity_title)
        self.activity_list = Gtk.ListBox(css_classes=["boxed-list"], selection_mode=Gtk.SelectionMode.NONE)
        content.append(self.activity_list)

        clamp.set_child(content)
        scroller.set_child(clamp)
        self.append(scroller)

    def refresh(self) -> None:
        from ..widgets.tool_card import ToolCard  # local import avoids cycle

        db = self.window.database
        detector = self.window.detector
        all_tools = db.all()
        installed = [t for t in all_tools if detector.is_installed(t)]

        self.total_card.set_value(str(len(all_tools)))
        self.installed_card.set_value(str(len(installed)))
        self.updates_card.set_value("0")
        self.storage_card.set_value(f"{sum(t.size_estimate_mb for t in installed)} MB")
        self.queue_card.set_value("0")

        child = self.recommended_box.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.recommended_box.remove(child)
            child = nxt

        recommended = db.by_category("recommended")[:6]
        for tool in recommended:
            card = ToolCard(self.window, tool)
            self.recommended_box.append(card)

        child = self.activity_list.get_first_child()
        while child:
            nxt = child.get_next_sibling()
            self.activity_list.remove(child)
            child = nxt
        row = Adw.ActionRow(title="No recent activity yet",
                             subtitle="Installs, updates and removals will appear here")
        self.activity_list.append(row)
