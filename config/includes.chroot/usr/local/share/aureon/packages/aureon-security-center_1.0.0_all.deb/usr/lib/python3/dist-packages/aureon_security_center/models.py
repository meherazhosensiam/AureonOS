"""Typed data models used throughout AUREON Security Center."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class InstallMethod(str, Enum):
    """Whitelisted installation back-ends.

    The installer only ever knows how to build a command for one of these
    fixed methods -- there is no "run this arbitrary command" method.
    """

    APT = "apt"
    FLATPAK = "flatpak"
    SNAP = "snap"
    PIPX = "pipx"
    PIP = "pip"
    CARGO = "cargo"
    GO = "go"
    NPM = "npm"
    GIT = "git"
    APPIMAGE = "appimage"
    TARBALL = "tarball"


class Difficulty(str, Enum):
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"


class Category(str, Enum):
    DASHBOARD = "dashboard"
    RECOMMENDED = "recommended"
    RECONNAISSANCE = "reconnaissance"
    INFO_GATHERING = "information_gathering"
    OSINT = "osint"
    WEB_SECURITY = "web_security"
    NETWORK_SECURITY = "network_security"
    WIRELESS_SECURITY = "wireless_security"
    PASSWORD_AUDITING = "password_auditing"
    ACTIVE_DIRECTORY = "active_directory"
    EXPLOITATION = "exploitation"
    POST_EXPLOITATION = "post_exploitation"
    MALWARE_ANALYSIS = "malware_analysis"
    REVERSE_ENGINEERING = "reverse_engineering"
    DIGITAL_FORENSICS = "digital_forensics"
    MOBILE_SECURITY = "mobile_security"
    CLOUD_SECURITY = "cloud_security"
    CONTAINER_SECURITY = "container_security"
    ICS_IOT = "ics_iot"
    CRYPTOGRAPHY = "cryptography"
    FUZZING = "fuzzing"
    PRIVACY = "privacy"
    ANONYMOUS_BROWSING = "anonymous_browsing"
    UTILITIES = "utilities"


CATEGORY_LABELS: dict[str, str] = {
    Category.DASHBOARD: "Dashboard",
    Category.RECOMMENDED: "Recommended for Beginners",
    Category.RECONNAISSANCE: "Reconnaissance",
    Category.INFO_GATHERING: "Information Gathering",
    Category.OSINT: "OSINT",
    Category.WEB_SECURITY: "Web Security",
    Category.NETWORK_SECURITY: "Network Security",
    Category.WIRELESS_SECURITY: "Wireless Security",
    Category.PASSWORD_AUDITING: "Password Auditing",
    Category.ACTIVE_DIRECTORY: "Active Directory",
    Category.EXPLOITATION: "Exploitation",
    Category.POST_EXPLOITATION: "Post Exploitation",
    Category.MALWARE_ANALYSIS: "Malware Analysis",
    Category.REVERSE_ENGINEERING: "Reverse Engineering",
    Category.DIGITAL_FORENSICS: "Digital Forensics",
    Category.MOBILE_SECURITY: "Mobile Security",
    Category.CLOUD_SECURITY: "Cloud Security",
    Category.CONTAINER_SECURITY: "Container Security",
    Category.ICS_IOT: "ICS / IoT",
    Category.CRYPTOGRAPHY: "Cryptography",
    Category.FUZZING: "Fuzzing",
    Category.PRIVACY: "Privacy",
    Category.ANONYMOUS_BROWSING: "Anonymous Browsing",
    Category.UTILITIES: "Utilities",
}


@dataclass(slots=True)
class Tool:
    """A single catalogued tool entry."""

    id: str
    name: str
    description: str
    category: str
    install_method: str
    package_name: str
    version: str = "latest"
    repository_url: str = ""
    github_url: str = ""
    documentation_url: str = ""
    homepage: str = ""
    icon: str = "applications-security-symbolic"
    license: str = "Unknown"
    dependencies: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    difficulty: str = Difficulty.INTERMEDIATE.value
    interface: str = "terminal"  # "terminal" or "gui"
    desktop_launcher: bool = False
    launch_command: str = ""
    size_estimate_mb: int = 0
    risks: str = ""
    when_to_use: str = ""
    recommended_tutorials: list[str] = field(default_factory=list)

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Tool":
        known = {f.name for f in Tool.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return Tool(**filtered)

    @property
    def category_label(self) -> str:
        return CATEGORY_LABELS.get(self.category, self.category.replace("_", " ").title())
