"""Loads and queries the tool catalogue (data/tools.json)."""

from __future__ import annotations

import json
from importlib import resources
from pathlib import Path
from typing import Iterable

from .logger import get_logger
from .models import Tool

log = get_logger("database")


class ToolDatabase:
    """In-memory catalogue of all known tools, loaded from JSON."""

    def __init__(self, extra_paths: Iterable[Path] | None = None) -> None:
        self._tools: dict[str, Tool] = {}
        self._load_bundled()
        for path in extra_paths or []:
            self._load_file(path)

    # -- loading -----------------------------------------------------
    def _load_bundled(self) -> None:
        try:
            data_text = resources.files("aureon_security_center").joinpath(
                "data/tools.json"
            ).read_text(encoding="utf-8")
        except (FileNotFoundError, ModuleNotFoundError):
            # Fallback for running from a source checkout without install.
            fallback = Path(__file__).parent / "data" / "tools.json"
            data_text = fallback.read_text(encoding="utf-8")
        self._ingest(json.loads(data_text))

    def _load_file(self, path: Path) -> None:
        if not path.exists():
            log.warning("Extra tool database not found: %s", path)
            return
        self._ingest(json.loads(path.read_text(encoding="utf-8")))

    def _ingest(self, records: list[dict]) -> None:
        for record in records:
            try:
                tool = Tool.from_dict(record)
                self._tools[tool.id] = tool
            except TypeError as exc:
                log.error("Skipping malformed tool entry %r: %s", record.get("id"), exc)
        log.info("Loaded %d tools into catalogue", len(self._tools))

    # -- queries -------------------------------------------------------
    def all(self) -> list[Tool]:
        return sorted(self._tools.values(), key=lambda t: t.name.lower())

    def get(self, tool_id: str) -> Tool | None:
        return self._tools.get(tool_id)

    def by_category(self, category: str) -> list[Tool]:
        return [t for t in self.all() if t.category == category]

    def search(self, query: str) -> list[Tool]:
        q = query.strip().lower()
        if not q:
            return self.all()
        results = []
        for tool in self.all():
            haystack = " ".join(
                [
                    tool.name,
                    tool.description,
                    tool.category_label,
                    tool.difficulty,
                    " ".join(tool.tags),
                ]
            ).lower()
            if q in haystack:
                results.append(tool)
        return results

    def count(self) -> int:
        return len(self._tools)
