"""CLI/desktop entry point.

Installed as the ``aureon-security-center`` console script and invoked by
the ``.desktop`` launcher.
"""

from __future__ import annotations

import sys


def main() -> int:
    from .application import AureonApplication

    app = AureonApplication()
    return app.run(sys.argv)


if __name__ == "__main__":
    sys.exit(main())
