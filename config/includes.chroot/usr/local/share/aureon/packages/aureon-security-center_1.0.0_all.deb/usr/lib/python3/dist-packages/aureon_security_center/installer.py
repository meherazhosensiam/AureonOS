"""The installation engine.

Design goals (see the project README's "Security" section for more detail):

* No arbitrary command execution. Every command run by this module is built
  from a small, fixed set of templates keyed by :class:`InstallMethod`. User
  input (search text, tool selection) only ever selects *which* catalogued
  tool to act on -- it is never concatenated into a shell string.
* No ``shell=True`` anywhere. All commands are passed to ``subprocess`` as
  argument lists.
* Anything that needs to modify the system (apt, global npm/cargo/go
  installs, writing desktop files/binaries outside $HOME) is escalated with
  ``pkexec`` on a per-action basis. AUREON Security Center itself never runs
  as root.
* Every action is logged (see :mod:`aureon_security_center.logger`).
* Network operations are retried with backoff, and package checksums are
  verified when the catalogue provides one.
"""

from __future__ import annotations

import enum
import hashlib
import shutil
import subprocess
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from pathlib import Path

from .logger import get_logger
from .models import InstallMethod, Tool

log = get_logger("installer")

LOCAL_BIN = Path.home() / ".local" / "bin"
APPIMAGE_DIR = Path.home() / ".local" / "share" / "aureon-security-center" / "appimages"
GIT_CLONE_DIR = Path.home() / ".local" / "share" / "aureon-security-center" / "src"

MAX_RETRIES = 3
RETRY_BACKOFF_SECONDS = 2


class ActionKind(str, enum.Enum):
    INSTALL = "install"
    REMOVE = "remove"
    UPDATE = "update"


class StepStatus(str, enum.Enum):
    STARTED = "started"
    PROGRESS = "progress"
    RETRYING = "retrying"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


@dataclass
class StepEvent:
    """A single progress event emitted while a command runs.

    The UI layer subscribes to a stream of these to update progress bars /
    the advanced-mode terminal log view.
    """

    tool_id: str
    kind: ActionKind
    status: StepStatus
    message: str
    line: str | None = None


ProgressCallback = Callable[[StepEvent], None]


class InstallError(RuntimeError):
    """Raised when an installation/removal/update step ultimately fails."""


class ChecksumMismatchError(InstallError):
    """Raised when a downloaded artefact's checksum does not match."""


def _requires_privilege(method: InstallMethod) -> bool:
    return method in {InstallMethod.APT, InstallMethod.SNAP}


def build_command(tool: Tool, action: ActionKind) -> list[str]:
    """Build the exact argv for the requested action on this tool.

    This is the single choke point through which every system-modifying
    command must pass, which is what makes the "never execute arbitrary
    code" guarantee auditable in one place.
    """
    method = InstallMethod(tool.install_method)
    pkg = tool.package_name

    if method is InstallMethod.APT:
        verb = {"install": "install", "remove": "remove", "update": "install"}[action.value]
        cmd = ["apt-get", verb, "-y", pkg]
        return ["pkexec"] + cmd

    if method is InstallMethod.FLATPAK:
        if action is ActionKind.INSTALL:
            return ["flatpak", "install", "-y", "--user", "flathub", pkg]
        if action is ActionKind.REMOVE:
            return ["flatpak", "uninstall", "-y", "--user", pkg]
        return ["flatpak", "update", "-y", "--user", pkg]

    if method is InstallMethod.SNAP:
        if action is ActionKind.REMOVE:
            return ["pkexec", "snap", "remove", pkg]
        return ["pkexec", "snap", "install", pkg]

    if method is InstallMethod.PIPX:
        if action is ActionKind.INSTALL:
            return ["pipx", "install", pkg]
        if action is ActionKind.REMOVE:
            return ["pipx", "uninstall", pkg]
        return ["pipx", "upgrade", pkg]

    if method is InstallMethod.PIP:
        if action is ActionKind.REMOVE:
            return ["python3", "-m", "pip", "uninstall", "-y", "--user", pkg]
        return ["python3", "-m", "pip", "install", "--user", "--upgrade", pkg]

    if method is InstallMethod.CARGO:
        if action is ActionKind.REMOVE:
            return ["cargo", "uninstall", pkg]
        return ["cargo", "install", "--locked", pkg]

    if method is InstallMethod.GO:
        if action is ActionKind.REMOVE:
            binary = LOCAL_BIN / pkg.rsplit("/", 1)[-1]
            return ["rm", "-f", str(binary)]
        return ["go", "install", f"{pkg}@latest"]

    if method is InstallMethod.NPM:
        if action is ActionKind.REMOVE:
            return ["npm", "uninstall", "-g", pkg]
        return ["npm", "install", "-g", pkg]

    if method is InstallMethod.GIT:
        dest = GIT_CLONE_DIR / tool.id
        if action is ActionKind.REMOVE:
            return ["rm", "-rf", str(dest)]
        if action is ActionKind.UPDATE:
            return ["git", "-C", str(dest), "pull", "--ff-only"]
        return ["git", "clone", "--depth", "1", tool.repository_url or tool.github_url, str(dest)]

    if method in {InstallMethod.APPIMAGE, InstallMethod.TARBALL}:
        # Download/extraction handled separately by download_artifact(); this
        # command only covers removal of a previously-fetched artefact.
        target = APPIMAGE_DIR / f"{tool.id}.AppImage"
        if action is ActionKind.REMOVE:
            return ["rm", "-f", str(target)]
        return ["echo", f"Use download_artifact() for {tool.id}"]

    raise InstallError(f"Unsupported install method: {method}")


class InstallationEngine:
    """Runs whitelisted install/remove/update commands with retries,
    checksum verification and structured progress reporting."""

    def __init__(self) -> None:
        LOCAL_BIN.mkdir(parents=True, exist_ok=True)
        APPIMAGE_DIR.mkdir(parents=True, exist_ok=True)
        GIT_CLONE_DIR.mkdir(parents=True, exist_ok=True)

    # -- public API ------------------------------------------------------
    def install(self, tool: Tool, on_event: ProgressCallback | None = None) -> None:
        self._run_action(tool, ActionKind.INSTALL, on_event)
        self._create_desktop_integration(tool)

    def remove(self, tool: Tool, on_event: ProgressCallback | None = None) -> None:
        self._run_action(tool, ActionKind.REMOVE, on_event)
        self._remove_desktop_integration(tool)

    def update(self, tool: Tool, on_event: ProgressCallback | None = None) -> None:
        self._run_action(tool, ActionKind.UPDATE, on_event)

    def launch(self, tool: Tool) -> subprocess.Popen:
        if not tool.launch_command:
            raise InstallError(f"{tool.name} has no configured launch command")
        argv = tool.launch_command.split()
        log.info("Launching %s: %s", tool.id, argv)
        return subprocess.Popen(argv)

    # -- internals ---------------------------------------------------------
    def _run_action(
        self, tool: Tool, action: ActionKind, on_event: ProgressCallback | None
    ) -> None:
        def emit(status: StepStatus, message: str, line: str | None = None) -> None:
            if on_event:
                on_event(StepEvent(tool.id, action, status, message, line))
            log.info("[%s] %s: %s", tool.id, action.value, message)

        method = InstallMethod(tool.install_method)

        if method in {InstallMethod.APPIMAGE, InstallMethod.TARBALL} and action is ActionKind.INSTALL:
            self.download_artifact(tool, on_event)
            return

        cmd = build_command(tool, action)
        self._check_binary_available(cmd[0] if cmd[0] != "pkexec" else cmd[1])

        emit(StepStatus.STARTED, f"Running: {' '.join(cmd)}")

        last_error: Exception | None = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                self._run_and_stream(cmd, emit)
                emit(StepStatus.SUCCEEDED, f"{tool.name} {action.value} completed")
                return
            except subprocess.CalledProcessError as exc:
                last_error = exc
                if attempt < MAX_RETRIES:
                    emit(
                        StepStatus.RETRYING,
                        f"Attempt {attempt} failed (exit {exc.returncode}), retrying...",
                    )
                    time.sleep(RETRY_BACKOFF_SECONDS * attempt)
                else:
                    emit(StepStatus.FAILED, f"Failed after {MAX_RETRIES} attempts: {exc}")

        raise InstallError(str(last_error)) from last_error

    def _run_and_stream(self, cmd: list[str], emit: Callable[..., None]) -> None:
        process = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1
        )
        assert process.stdout is not None
        for line in process.stdout:
            emit(StepStatus.PROGRESS, "output", line.rstrip())
        returncode = process.wait()
        if returncode != 0:
            raise subprocess.CalledProcessError(returncode, cmd)

    def _check_binary_available(self, binary: str) -> None:
        if binary in {"rm", "echo"}:
            return
        if shutil.which(binary) is None:
            raise InstallError(
                f"Required tool '{binary}' is not available on this system. "
                "Install it first (e.g. from Settings > Default installation method)."
            )

    # -- checksum-verified artefact download (AppImage / tarball) --------
    def download_artifact(self, tool: Tool, on_event: ProgressCallback | None = None) -> Path:
        import urllib.request

        def emit(status: StepStatus, message: str, line: str | None = None) -> None:
            if on_event:
                on_event(StepEvent(tool.id, ActionKind.INSTALL, status, message, line))

        url = tool.repository_url or tool.homepage
        if not url:
            raise InstallError(f"No download URL configured for {tool.name}")

        dest = APPIMAGE_DIR / f"{tool.id}.AppImage"
        emit(StepStatus.STARTED, f"Downloading {tool.name} from {url}")

        last_error: Exception | None = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                with urllib.request.urlopen(url, timeout=30) as response, open(dest, "wb") as fh:
                    shutil.copyfileobj(response, fh)
                break
            except Exception as exc:  # network errors of various kinds
                last_error = exc
                if attempt < MAX_RETRIES:
                    emit(StepStatus.RETRYING, f"Download attempt {attempt} failed, retrying...")
                    time.sleep(RETRY_BACKOFF_SECONDS * attempt)
                else:
                    emit(StepStatus.FAILED, f"Download failed: {exc}")
                    raise InstallError(str(exc)) from last_error

        expected_sha256 = getattr(tool, "sha256", "") or ""
        if expected_sha256:
            actual = self._sha256_of(dest)
            if actual.lower() != expected_sha256.lower():
                dest.unlink(missing_ok=True)
                raise ChecksumMismatchError(
                    f"Checksum mismatch for {tool.name}: expected {expected_sha256}, got {actual}"
                )
            emit(StepStatus.PROGRESS, "Checksum verified")

        dest.chmod(0o755)
        emit(StepStatus.SUCCEEDED, f"{tool.name} downloaded to {dest}")
        return dest

    @staticmethod
    def _sha256_of(path: Path) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()

    # -- desktop integration ---------------------------------------------
    def _create_desktop_integration(self, tool: Tool) -> None:
        if not tool.desktop_launcher or not tool.launch_command:
            return
        apps_dir = Path.home() / ".local" / "share" / "applications"
        apps_dir.mkdir(parents=True, exist_ok=True)
        desktop_file = apps_dir / f"aureon-{tool.id}.desktop"
        desktop_file.write_text(
            "\n".join(
                [
                    "[Desktop Entry]",
                    "Type=Application",
                    f"Name={tool.name}",
                    f"Comment={tool.description}",
                    f"Exec={tool.launch_command}",
                    f"Icon={tool.icon}",
                    f"Categories=Security;{tool.category_label.replace(' ', '')};",
                    "Terminal=" + ("true" if tool.interface == "terminal" else "false"),
                ]
            )
            + "\n",
            encoding="utf-8",
        )
        log.info("Created desktop launcher: %s", desktop_file)

    def _remove_desktop_integration(self, tool: Tool) -> None:
        desktop_file = (
            Path.home() / ".local" / "share" / "applications" / f"aureon-{tool.id}.desktop"
        )
        if desktop_file.exists():
            desktop_file.unlink()
            log.info("Removed desktop launcher: %s", desktop_file)

    # -- housekeeping -------------------------------------------------------
    def clean_cache(self) -> None:
        """Clean package manager caches after a batch of installs."""
        if shutil.which("apt-get"):
            subprocess.run(["pkexec", "apt-get", "clean"], check=False)
        if shutil.which("pip"):
            subprocess.run(["python3", "-m", "pip", "cache", "purge"], check=False)
        log.info("Caches cleaned")

    def refresh_package_lists(self) -> None:
        if shutil.which("apt-get"):
            subprocess.run(["pkexec", "apt-get", "update"], check=False)
            log.info("apt package lists refreshed")
